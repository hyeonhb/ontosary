"""Offline original/candidate policy, trace, input and termination evidence audit."""
import hashlib,json,pathlib,re,tarfile,tempfile
from policy import verify,baseline_verify
from scope import verify as verify_scope
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def verify_pair(work):
 root=work/'guest';prior=read(work/'prior-native.json');old=read(root/'baseline/native.json');new=read(root/'candidate/native.json')
 baseline_verify(old,prior);diff=verify(new,old);assert new['Spec']['linux']['seccomp']==read(root/'candidate.json')
 image=read(root/'image.json');config=(root/'preparation/config.oci').read_bytes();manifest=(root/'preparation/manifest.oci').read_bytes()
 assert 'sha256:'+sha(config)==image['config'] and 'sha256:'+sha(manifest)==image['target']
 chain=json.loads(config)['rootfs']['diff_ids'][0]
 for layer in json.loads(config)['rootfs']['diff_ids'][1:]:chain='sha256:'+sha((chain+' '+layer).encode())
 assert chain==image['chain']
 units=[];traces=[];inputs=[]
 for mode in ['baseline','candidate']:
  n=read(root/mode/'native.json');r=read(root/(mode+'-result.json'));term=read(root/mode/'termination.json');removed=read(root/mode/'removed.json');s=read(root/mode/'state.json');pre=read(root/mode/'pre-execution.json')
  assert n['SnapshotInfo']['Parent']==image['chain'] and n['Labels']['nerdctl/image-digest']==image['target']
  assert all(r['parent'].values()) and r['nodeVersion']=='v22.19.0' and r['calls'][0]['stdout']=='codex-cli 0.167.0-alpha.3.2\n'
  assert r['fixtureOnly'] and not r['validSubmission'] and all(r[k]==0 for k in ['credentialTransfers','logins','refreshes','providerRequests','modelCalls','trialRuns'])
  assert term['confirmed'] and term['kernel']['events']['populated']=='0' and not term['kernel']['members'] and term['runtimeState']['Pid']==0 and not term['runtimeState']['Running']
  assert s['cleanupDone'] and s['state']=='finalized' and not any(s.get(k) for k in ['createPending','startPending','execPending'])
  assert all(removed[k] for k in ['containerAbsent','runtimeTaskAbsent','noPendingRequests','terminationBeforeCollection']) and removed['seconds']<120
  assert term['confirmedAt']['mono']<removed['mono']
  assert pre['inputs'][str(pathlib.Path('/opt/ontosary-single-policy-test/probe/probe.mjs'))]==sha((root/'probe/probe.mjs').read_bytes())
  traces.append(r['calls'][-1]['stderr']);inputs.append(r['calls'][-1]['args'])
  units.append({'mode':mode,'containerId':s['containerId'],'seconds':removed['seconds'],'parent':r['parent'],'payloadStarted':r['nativePayloadStarted'],'exitCode':r['calls'][-1]['exitCode'],'nativeBinaryHashes':r['binaries']})
 assert inputs[0]==inputs[1] and units[0]['nativeBinaryHashes']==units[1]['nativeBinaryHashes']
 flags='CLONE_NEWNS|CLONE_NEWIPC|CLONE_NEWUSER|CLONE_NEWPID|CLONE_NEWNET|SIGCHLD'
 denied='clone(child_stack=NULL, flags='+flags+') = -1 EPERM'
 assert traces[0].count(denied)==2
 # strace may split clone into unfinished/resumed lines; preserve raw relation for review.
 direct=[line for line in traces[1].splitlines() if 'clone(child_stack=NULL, flags='+flags+')' in line or '<... clone resumed>' in line]
 positive=[line for line in direct if re.search(r'= [1-9][0-9]*$',line)]
 payload=units[1]['payloadStarted']
 outcome='synthetic-payload-completed' if payload else 'first-clone-passed-next-blocked' if positive else 'clone-still-denied' if denied in traces[1] else 'inconclusive'
 assert read(work/'host-cleanup.json')['rootAbsent']
 unchanged=read(work/'start-input-hashes.json')
 for name,digest in unchanged.items():assert sha(pathlib.Path(name).read_bytes())==digest,name
 return {'completion':'completed','outcome':outcome,'policy':diff,'units':units,'candidateCloneLines':direct,'positiveCloneLines':positive,'originalInputsUnchanged':len(unchanged),'candidateApplications':1,'candidateStarts':1,'containers':2,'nonModelCLICalls':4,'tracedCLIInvocations':2,'fixtureOnly':True,'validSubmission':False,'trialAuthorized':False,'readyForTrial':False,'results':None,'R11':'unresolved','credentialProviderModelTrialCalls':0}
if __name__=='__main__':
 work=pathlib.Path('work/s2-single-policy-test');result=verify_pair(work);scope=read(work/'analysis-scope.json');result['snapshots']=verify_scope(work/'snapshots',scope);(work/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
