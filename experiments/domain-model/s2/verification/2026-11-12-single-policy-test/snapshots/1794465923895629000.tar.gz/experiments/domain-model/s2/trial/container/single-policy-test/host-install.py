"""Transfer fixed diagnostic helpers and run at most two preparation units."""
import hashlib,json,os,pathlib,subprocess,tarfile
root=pathlib.Path('/tmp/ontosary-s2-single-policy-test-20261112');work=pathlib.Path('work/s2-single-policy-test');base=pathlib.Path('experiments/domain-model/s2/trial/container');src=base/'single-policy-test';os.environ['LIMA_HOME']=str(root/'lima');lima=str(root/'prefix/bin/limactl')
archive=work/'inputs.tar.gz';members={}
files=[(work/'Dockerfile','build/Dockerfile'),(base/'cli-feasibility/policy.toml','policy.toml'),(src/'probe.mjs','probe/probe.mjs'),(src/'guest.py','guest.py'),(src/'export.py','export.py'),(src/'job.py','job.py'),(src/'policy.py','policy.py'),(work/'prior-native.json','prior-native.json'),(work/'budget.json','budget.json')]+[(p,'lifecycle/'+p.name) for p in (base/'lifecycle').glob('*.py')]
with tarfile.open(archive,'w:gz') as t:
 for p,name in files:t.add(p,arcname=name);members[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(work/'inputs.json').write_text(json.dumps({'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members},indent=2)+'\n')
def run(args,timeout=30,check=True):return subprocess.run([lima,*args],check=check,timeout=timeout)
run(['copy',str(archive),'s2-lifecycle:/tmp/s2-single-policy-inputs.tar.gz'])
run(['shell','--workdir=/tmp','s2-lifecycle','sudo','mkdir','/opt/ontosary-single-policy-test'])
run(['shell','--workdir=/tmp','s2-lifecycle','sudo','tar','-xzf','/tmp/s2-single-policy-inputs.tar.gz','-C','/opt/ontosary-single-policy-test'])
run(['shell','--workdir=/tmp','s2-lifecycle','sudo','mkdir','-p','/opt/ontosary-fixture/code'])
run(['shell','--workdir=/tmp','s2-lifecycle','sudo','cp','-a','/opt/ontosary-single-policy-test/lifecycle/.','/opt/ontosary-fixture/code/'])
result=run(['shell','--workdir=/tmp','s2-lifecycle','sudo','python3','/opt/ontosary-single-policy-test/guest.py'],650,False)
run(['shell','--workdir=/tmp','s2-lifecycle','sudo','python3','/opt/ontosary-single-policy-test/export.py'])
run(['copy','s2-lifecycle:/tmp/s2-single-policy-evidence.tar.gz',str(work/'guest-evidence.tar.gz')])
with tarfile.open(work/'guest-evidence.tar.gz') as t:t.extractall(work/'guest',filter='data')
raise SystemExit(result.returncode)
