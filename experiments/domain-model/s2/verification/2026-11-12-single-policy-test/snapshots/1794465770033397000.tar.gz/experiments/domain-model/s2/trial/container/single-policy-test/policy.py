"""Reject every security change except the one exact approved clone row."""
import copy
RULE={'names':['clone'],'action':'SCMP_ACT_ALLOW','args':[{'index':0,'op':'SCMP_CMP_EQ','value':2013397009}]}
def security(n):
 s=copy.deepcopy(n['Spec']);p=s['process'];l=s['linux']
 return {'process':{k:v for k,v in p.items() if k not in ['args','env','cwd']},'linux':{k:v for k,v in l.items() if k!='cgroupsPath'},'rootReadonly':s['root']['readonly'],'mounts':[{k:v for k,v in m.items() if k!='source'}|{'source':m['source'] if m['type']!='bind' else '<per-role-bind>'} for m in s['mounts']],'network':s['annotations']['nerdctl/networks']}
def verify(candidate,baseline):
 expected=security(baseline);expected['linux']['seccomp']['syscalls'].append(copy.deepcopy(RULE))
 assert security(candidate)==expected,'policy-or-security-mismatch'
 return {'exactAddedRule':RULE,'otherSecurityUnchanged':True}
def baseline_verify(n,prior):assert security(n)==security(prior),'baseline-security-mismatch'
