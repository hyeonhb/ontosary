from pathlib import Path
p=Path('experiments/domain-model/s2/trial/container/lifecycle/collector.py');s=p.read_text();start=s.index('                source=os.open');end=s.index('\n            else:raise Rejected',start)
s=s[:start]+'''                target=destination/rel if destination else None
                if target:target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
                manifest[rel]=read_regular(fd,name,before,end,target)
                if fail_after is not None and count>=fail_after:raise Rejected('injected-copy-failure')'''+s[end:]
insert='''
def open_directory(path):
    """Walk every ancestor by FD. No parent symlink is followed."""
    path=pathlib.Path(path)
    if not path.is_absolute() or '..' in path.parts:raise Rejected('absolute-directory-required')
    fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY)
    try:
        for part in path.parts[1:]:
            child=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
            os.close(fd);fd=child
        return fd
    except BaseException:os.close(fd);raise

def read_regular(fd,name,before,end,target=None,owner=None,sealed=False):
    """Shared collector/export body reader; caller checks quota before this open."""
    if not stat.S_ISREG(before.st_mode):raise Rejected('nonregular:'+name)
    if before.st_nlink!=1:raise Rejected('hardlink:'+name)
    if owner is not None and before.st_uid!=owner:raise Rejected('file-owner:'+name)
    if sealed and before.st_mode&0o222:raise Rejected('unsealed-file:'+name)
    source=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
    def identity(st):return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns,st.st_nlink,st.st_uid,st.st_mode)
    try:
        if identity(os.fstat(source))!=identity(before):raise Rejected('file-changed:'+name)
        h=hashlib.sha256();n=0;dest=target.open('xb') if target else None
        try:
            while True:
                if time.monotonic()>=end:raise Rejected('collection-time-limit')
                chunk=os.read(source,65536)
                if not chunk:break
                n+=len(chunk)
                if n>before.st_size:raise Rejected('file-grew:'+name)
                h.update(chunk)
                if dest:dest.write(chunk)
            if n!=before.st_size or identity(os.fstat(source))!=identity(before) or identity(os.stat(name,dir_fd=fd,follow_symlinks=False))!=identity(before):raise Rejected('file-changed:'+name)
        finally:
            if dest:dest.close()
        return {'sha256':h.hexdigest(),'bytes':n}
    finally:os.close(source)

class SafeFiles:
    """One cumulative export budget, including generated metadata."""
    def __init__(self,staging,deadline,max_files=1024,max_bytes=16*1024*1024):
        self.staging=pathlib.Path(staging);self.deadline=deadline;self.max_files=max_files;self.max_bytes=max_bytes;self.members={};self.bytes=0
    def reserve(self,name,size):
        if time.monotonic()>=self.deadline:raise Rejected('collection-time-limit')
        parts=pathlib.PurePosixPath(name).parts
        if not parts or len(parts)>16 or name.startswith('/') or '..' in parts or name in self.members:raise Rejected('export-name')
        if len(self.members)+1>self.max_files:raise Rejected('file-count-limit')
        if self.bytes+size>self.max_bytes:raise Rejected('byte-limit')
        self.bytes+=size
        target=self.staging/name;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700);return target
    def copy(self,path,name,sealed=False):
        path=pathlib.Path(path);fd=open_directory(path.parent)
        try:
            before=os.stat(path.name,dir_fd=fd,follow_symlinks=False)
            target=self.reserve(name,before.st_size)
            row=read_regular(fd,path.name,before,self.deadline,target,os.getuid(),sealed)
            self.members[name]=row;return target
        finally:os.close(fd)
    def metadata(self,name,value):
        data=(json.dumps(value,sort_keys=True,indent=2)+'\\n').encode();target=self.reserve(name,len(data));target.write_bytes(data);self.members[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};return target
'''
s=s.replace('\ndef inventory(',insert+'\ndef inventory(');p.write_text(s)
