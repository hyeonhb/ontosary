import datetime,json,pathlib,time
w=pathlib.Path('work/s2-linux-evaluation');budget=json.loads((w/'budget.json').read_text());start=budget['monotonic'];now=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
first_final=next(e for e in budget['events'] if e['log'].endswith('validation-baseline-1.log'))
preparation_charge=first_final['monotonic']-start
previous=json.loads(pathlib.Path('experiments/domain-model/s2/verification/2026-11-11-lifecycle-fixture/cost.json').read_text())
env_event=next(e for e in budget['events'] if e['log'].endswith('linux-preparation.log'));core_event=next(e for e in budget['events'] if e['log'].endswith('core-comparison-v2.log'));explore_event=next(e for e in budget['events'] if e['log'].endswith('lifecycle-regressions.log'))
measured_preparation=sum(e['seconds'] for e in budget['events'] if e['log'].endswith(('host-preparation.log','linux-preparation.log','job-setup.log')))
cost={'startedUtc':budget['utc'],'finishedUtc':utc,'startedHostMonotonic':start,'finishedHostMonotonic':now,'measuredRoundSeconds':now-start,'environmentSeconds':preparation_charge,'environmentChargingBasis':'Conservative first-clock to first final-validation unit invocation. Includes reading/design, source packaging, installation, assembly, path diagnosis and all three preliminary units; not pure install runtime. Later repeated fingerprints are included in whole-round cost.','measuredPreparationCommandsSeconds':measured_preparation,'previousEnvironmentSeconds':previous['cumulativeEnvironmentSeconds'],'cumulativeEnvironmentSeconds':previous['cumulativeEnvironmentSeconds']+preparation_charge,'previousRoundSecondsIncludingEstimates':previous['cumulativeRoundSecondsIncludingPriorEstimates'],'cumulativeRoundSecondsIncludingPriorEstimates':previous['cumulativeRoundSecondsIncludingPriorEstimates']+now-start,'milestones':{'environmentOpenSeconds':env_event['monotonic']+env_event['seconds']-start,'coreComparisonSeconds':core_event['monotonic']+core_event['seconds']-start,'requiredRunsAndRegressionsSeconds':explore_event['monotonic']+explore_event['seconds']-start,'finalSeconds':now-start},'limitsSeconds':{'environment':2700,'core':5400,'exploration':9000,'finish':10800},'candidateCount':1,'vmPreparations':1,'registeredUnits':17,'finalCalibrationUnits':7,'preliminaryUnits':3,'jobProbes':2,'sharedLifecycleRegressions':5,'preparationContainers':4,'paidCost':0,'actualCLIInvocations':0,'modelCalls':0,'providerCalls':0,'trialRuns':0,'gitDelivery':'Excluded; begins at this checkpoint. No experiments resume.','measurementBoundary':'Completed checks, resource cleanup, report/evidence review, immediately before final cost table/index refresh. Original start clock is never reset.'}
assert all(cost['milestones'][k]<=v for k,v in [('environmentOpenSeconds',2700),('coreComparisonSeconds',5400),('requiredRunsAndRegressionsSeconds',9000),('finalSeconds',10800)])
(w/'cost.json').write_text(json.dumps(cost,indent=2)+'\n')
p=pathlib.Path('docs/reviews/2026-11-11-s2-linux-evaluation.md');s=p.read_text();startmark='<!-- COST_TABLE -->';endmark='<!-- END_COST_TABLE -->'
table=f'''{startmark}
| 구분 | 이전 누적 | 이번 회차 | 새 누적 |
| --- | ---: | ---: | ---: |
| 환경 보수 청구 | {cost['previousEnvironmentSeconds']:.3f}s | {preparation_charge:.3f}s | {cost['cumulativeEnvironmentSeconds']:.3f}s |
| 전체 회차(이전 추정 포함) | {cost['previousRoundSecondsIncludingEstimates']:.3f}s | {now-start:.3f}s | {cost['cumulativeRoundSecondsIncludingPriorEstimates']:.3f}s |

이번 환경 청구는 최초 시계부터 최종 검증 첫 단위 시작까지로 읽기/설계·초기3개 실행·경로 진단도 포함한 보수적 값이다. 직접 계측한 VM/설치/조립 준비 명령 합계는{measured_preparation:.3f}s이며 전체 wall과 중복해 더하지 않는다. 원래 환경 열기 {cost['milestones']['environmentOpenSeconds']:.3f}s, 핵심 대조 {cost['milestones']['coreComparisonSeconds']:.3f}s, 필수 실행/회귀 {cost['milestones']['requiredRunsAndRegressionsSeconds']:.3f}s에 각각 확보했다. 최종 시각은 `{utc}`다.
{endmark}'''
if endmark in s:a=s.index(startmark);b=s.index(endmark)+len(endmark);s=s[:a]+table+s[b:]
else:s=s.replace(startmark,table)
p.write_text(s);print(json.dumps({'roundSeconds':now-start,'environmentChargedSeconds':preparation_charge,'finishedUtc':utc}))
