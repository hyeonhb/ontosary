import subprocess
base='experiments/domain-model/s2/trial/container/linux-evaluation/'
for index,job in enumerate(['baseline','reference','helper-type-error','wrong-modal-order','reference-delta'],start=3):
 args=['python3',base+'command.py','--ledger','work/s2-linux-evaluation/budget.json','--log',f'work/s2-linux-evaluation/validation-{index}-{job}.log','--phase','exploration','--timeout','240','--','python3',base+'run.py','--root','/tmp/ontosary-s2-linux-evaluation-20261111','--output','work/s2-linux-evaluation/validation-units','--job',job,'--budget','work/s2-linux-evaluation/budget.json','--phase','exploration']
 subprocess.run(args,check=True,timeout=250)
