import os,subprocess,pathlib
root=pathlib.Path('/tmp/ontosary-s2-linux-evaluation-20261111');os.environ['LIMA_HOME']=str(root/'lima');lima=str(root/'prefix/bin/limactl')
def cmd(args,t=30):subprocess.run([lima,*args],check=True,timeout=t)
cmd(['copy','work/s2-linux-evaluation/job-code.tar.gz','s2-lifecycle:/tmp/s2-job-code.tar.gz'])
cmd(['shell','--workdir=/tmp','s2-lifecycle','sudo','mkdir','/tmp/s2-job-code'])
cmd(['shell','--workdir=/tmp','s2-lifecycle','sudo','tar','-xzf','/tmp/s2-job-code.tar.gz','-C','/tmp/s2-job-code'])
cmd(['shell','--workdir=/tmp','s2-lifecycle','sudo','mv','/tmp/s2-job-code/fixture','/opt/ontosary-fixture'])
cmd(['shell','--workdir=/tmp','s2-lifecycle','sudo','cp','/tmp/s2-job-code/evaluation/tools/assemble.mjs','/tmp/s2-job-code/evaluation/tools/job.mjs','/opt/ontosary-linux-evaluation/tools/'])
cmd(['shell','--workdir=/tmp','s2-lifecycle','sudo','python3','/tmp/s2-job-code/setup.py'],150)
