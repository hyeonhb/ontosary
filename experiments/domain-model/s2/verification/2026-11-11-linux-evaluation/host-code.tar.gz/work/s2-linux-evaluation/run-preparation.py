import os,pathlib,subprocess
root=pathlib.Path('/tmp/ontosary-s2-linux-evaluation-20261111');os.environ['LIMA_HOME']=str(root/'lima');lima=str(root/'prefix/bin/limactl')
def cmd(args,t):subprocess.run([lima,*args],check=True,timeout=t)
cmd(['copy','work/s2-linux-evaluation/inputs.tar.gz','s2-lifecycle:/tmp/s2-linux-inputs.tar.gz'],120)
cmd(['copy','experiments/domain-model/s2/trial/container/linux-evaluation/prepare.py','s2-lifecycle:/tmp/s2-linux-prepare.py'],30)
cmd(['shell','--workdir=/tmp','s2-lifecycle','sudo','mkdir','/opt/ontosary-linux-evaluation'],30)
cmd(['shell','--workdir=/tmp','s2-lifecycle','sudo','tar','-xzf','/tmp/s2-linux-inputs.tar.gz','-C','/opt/ontosary-linux-evaluation'],60)
cmd(['shell','--workdir=/tmp','s2-lifecycle','sudo','python3','/tmp/s2-linux-prepare.py'],1500)
