import datetime,hashlib,json,os,pathlib,shutil,subprocess,time
base=pathlib.Path('work/s2-lifecycle-fixture');owned=json.loads((base/'ownership.json').read_text());root=pathlib.Path(owned['taskRoot']);rows=[]
assert str(root)=='/tmp/ontosary-s2-lifecycle-20261110'
assert not (root/'lima/s2-lifecycle').exists()
result=subprocess.run([str(root/'prefix/bin/limactl'),'list','--json'],env={**os.environ,'LIMA_HOME':str(root/'lima')},capture_output=True,text=True,timeout=10)
assert result.returncode==0 and 's2-lifecycle' not in result.stdout
for row in owned['cache']:
 p=pathlib.Path(row['path']);assert not row['existedBefore'];assert (p/'url').read_text().strip()==row['url']
 assert p.name==hashlib.sha256(row['url'].encode()).hexdigest()
 data=p/'data';h=hashlib.file_digest(data.open('rb'),'sha256').hexdigest();expected=(p/'sha256.digest').read_text().strip().removeprefix('sha256:');assert h==expected
 files=[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.file_digest(f.open('rb'),'sha256').hexdigest()} for f in p.rglob('*') if f.is_file()]
 rows.append({**row,'sha256':h,'bytes':data.stat().st_size,'files':files});shutil.rmtree(p);assert not p.exists()
# Only the current task's owned prefix/VM/download tree is removed.
shutil.rmtree(root);assert not root.exists()
ps=subprocess.run(['ps','-axo','pid=,comm=,args='],capture_output=True,text=True,timeout=5)
remaining=[line for line in ps.stdout.splitlines() if str(root) in line and ('/bin/limactl hostagent' in line or '/bin/limactl start' in line) and ' zsh ' not in line]
assert not remaining,remaining
record={'status':'cleanup-passed','vmAbsent':True,'taskRootAbsent':True,'ownedCachesRemoved':rows,'hostAgentAbsent':True,'limaList':result.stdout,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hostMono':time.monotonic()}
(base/'cleanup.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
