import json,pathlib
base=pathlib.Path('work/s2-lifecycle-fixture');rows=json.loads((base/'selected.json').read_text());out=[]
for row in rows:
 r=base/'guest-final/runs'/row['runId'];s=json.loads((r/'state.json').read_text());events=[json.loads(l) for l in (r/'events.jsonl').read_text().splitlines()];term=next(e['termination'] for e in events if e['kind']=='stopped-confirmed')
 x={'mode':row['mode'],'runId':row['runId'],'state':s['state'],'stopConfirmationSeconds':term['confirmedAt']['mono']-term['stopRequested']['mono']}
 if s['mode']=='timeout':x['deadlineLagSeconds']=term['stopRequested']['mono']-s['deadlineMono']
 if s['mode']=='wrapper':x['leaseAgeSeconds']=term['stopRequested']['mono']-json.loads((r/'lease.json').read_text())['mono']
 if 'collectionFinished' in s:x['collectionSeconds']=s['collectionFinished']['mono']-s['collectionStarted']['mono']
 if s['mode']=='supervisor':
  x['cleanupGuestUTC']=next(e['utc'] for e in events if e['kind']=='cleanup-enter');x['hostInjectionUTC']=json.loads((base/'probes-v14'/row['runId']/'injection.json').read_text())['hostUtc']
 if s['mode']=='race':
  x['writersObserved']=len(list((r/'source').glob('writer-*')));x['cleanupCalls']=sum(e['kind']=='cleanup-enter' for e in events);x['cleanupDeferred']=sum(e['kind']=='cleanup-deferred' for e in events)
 if s['mode']=='publish-supervisor':x['revoked']=any(e['kind']=='result-revoked' for e in events)
 out.append(x)
if not (base/'metrics-initial.json').exists():(base/'metrics.json').rename(base/'metrics-initial.json')
(base/'metrics.json').write_text(json.dumps(out,indent=2)+'\n')
for key in ['stopConfirmationSeconds','collectionSeconds','deadlineLagSeconds','leaseAgeSeconds']:
 values=[r[key] for r in out if key in r];print(key,min(values),max(values))
print(json.dumps([r for r in out if r['mode'] in ['race','supervisor','publish-supervisor']],indent=2))
