import pathlib,shutil,subprocess,sys,tarfile
v=sys.argv[1];base=pathlib.Path('work/s2-lifecycle-fixture');src=pathlib.Path('experiments/domain-model/s2/trial/container/lifecycle');dest=base/'versions'/v;dest.mkdir()
for p in src.iterdir():
 if p.is_file():shutil.copy2(p,dest/p.name)
archive=pathlib.Path('/tmp/ontosary-s2-lifecycle-20261110/downloads')/(v+'.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for p in dest.iterdir():t.add(p,arcname=p.name)
prefix=['python3',str(src/'command.py'),'--ledger',str(base/'budget.json'),'--phase','core','--timeout','15']
lima=['env','LIMA_HOME=/tmp/ontosary-s2-lifecycle-20261110/lima','/tmp/ontosary-s2-lifecycle-20261110/prefix/bin/limactl']
subprocess.run(prefix+['--log',str(base/(v+'-copy.log')),'--',*lima,'copy',str(archive),'s2-lifecycle:/tmp/'+v+'.tar.gz'],check=True)
subprocess.run(prefix+['--log',str(base/(v+'-deploy.log')),'--',*lima,'shell','--workdir=/tmp','s2-lifecycle','sudo','tar','xzf','/tmp/'+v+'.tar.gz','-C','/opt/ontosary-fixture/code'],check=True)
