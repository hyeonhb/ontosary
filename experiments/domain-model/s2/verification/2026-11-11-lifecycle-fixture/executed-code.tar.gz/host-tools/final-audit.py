import json,pathlib,shutil,subprocess
base=pathlib.Path('work/s2-lifecycle-fixture');rows=[]
for p in (base/'probes-v14').glob('*/summary.json'):rows.append({**json.loads(p.read_text()),'version':'v14'})
assert len(rows)==25,len(rows);rows.sort(key=lambda r:(r['mode'],r['runId']))
if not (base/'selected-initial.json').exists():shutil.copyfile(base/'selected.json',base/'selected-initial.json')
(base/'selected.json').write_text(json.dumps(rows,indent=2)+'\n')
args=['python3','experiments/domain-model/s2/trial/container/lifecycle/command.py','--ledger',str(base/'budget.json'),'--log',str(base/'51-final-audit.log'),'--phase','exploration','--timeout','30','--','env','LIMA_HOME=/tmp/ontosary-s2-lifecycle-20261110-final/lima','/tmp/ontosary-s2-lifecycle-20261110-final/prefix/bin/limactl','shell','--workdir=/tmp','s2-lifecycle','sudo','python3','/opt/ontosary-fixture/code/audit.py',*[r['runId'] for r in rows]]
raise SystemExit(subprocess.run(args).returncode)
