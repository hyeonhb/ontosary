import json,pathlib,sys
sys.path.insert(0,'/opt/ontosary-fixture/code')
from common import *
run=runpath('35c4b4691c77')
events=[json.loads(l) for l in (run/'events.jsonl').read_text().splitlines()]
creation=[e for e in events if e['kind']=='command' and 'create' in e['command']][-1]
assert creation['exitCode']==1 and "invalid field 'rw' must be a key=value pair" in creation['stderr']
# Parser rejection is a completed pre-dispatch error, not an unknown runtime request.
assert cgroup_snapshot(run)['events']['populated']=='0'
code,out,err=command(run,NERD+['inspect','ontosary-'+run.name],check=False)
assert code!=0 and 'no such object' in err.lower(),(code,out,err)
command(run,CTR+['tasks','list']);event(run,'parser-rejection-reconciled',basis=creation)
state(run,createPending=False);cleanup(run)
print(read(run/'state.json'))
