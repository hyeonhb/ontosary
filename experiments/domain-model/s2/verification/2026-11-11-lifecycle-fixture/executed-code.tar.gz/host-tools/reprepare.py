import datetime,hashlib,json,os,pathlib,subprocess,tarfile,time
base=pathlib.Path('work/s2-lifecycle-fixture');root=pathlib.Path('/tmp/ontosary-s2-lifecycle-20261110-final');root.mkdir();(root/'downloads').mkdir();(root/'prefix').mkdir()
start={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mono':time.monotonic(),'reason':'Self-review found service failure after publication; same candidate, original round deadlines, no new budget.'}
old=json.loads((base/'ownership.json').read_text());owned={'taskRoot':str(root),'vm':'s2-lifecycle','cache':[{**r,'existedBefore':pathlib.Path(r['path']).exists()} for r in old['cache']],'start':start};assert not any(r['existedBefore'] for r in owned['cache']);(base/'ownership-final.json').write_text(json.dumps(owned,indent=2)+'\n')
command=['python3','experiments/domain-model/s2/trial/container/lifecycle/command.py','--ledger',str(base/'budget.json'),'--phase','exploration']
def run(label,timeout,args):subprocess.run(command+['--timeout',str(timeout),'--log',str(base/(label+'.log')),'--',*args],check=True)
run('42-final-download',60,['curl','-fL','--max-time','55','-o',str(root/'downloads/lima.tar.gz'),'https://github.com/lima-vm/lima/releases/download/v2.3.0/lima-2.3.0-Darwin-arm64.tar.gz'])
assert hashlib.file_digest((root/'downloads/lima.tar.gz').open('rb'),'sha256').hexdigest()=='b7af444bd8f91d3c307477e562f2cf3bd7595d62b9429185e4fa841563578cfc'
with tarfile.open(root/'downloads/lima.tar.gz') as t:t.extractall(root/'prefix',filter='data')
lima=['env','LIMA_HOME='+str(root/'lima'),str(root/'prefix/bin/limactl')]
run('43-final-vm-start',480,[*lima,'start','--yes','--name=s2-lifecycle','--timeout=7m','experiments/domain-model/s2/trial/container/lima.yaml'])
run('44-final-dockerfile-copy',15,[*lima,'copy','experiments/domain-model/s2/trial/container/Dockerfile','s2-lifecycle:/tmp/Dockerfile'])
run('45-final-build',180,[*lima,'shell','--workdir=/tmp','s2-lifecycle','sudo','sh','-c','mkdir /tmp/lifecycle-build; cp /tmp/Dockerfile /tmp/lifecycle-build/Dockerfile; nerdctl --address /run/containerd/containerd.sock --namespace default build --build-arg BASE_IMAGE=docker.io/library/node@sha256:4a4884e8a44826194dff92ba316264f392056cbe243dcc9fd3551e71cea02b90 -t ontosary-s2-lifecycle:20261110 /tmp/lifecycle-build'])
archive=root/'downloads/v14.tar.gz';source=pathlib.Path('experiments/domain-model/s2/trial/container/lifecycle');version=base/'versions/v14';version.mkdir()
import shutil
with tarfile.open(archive,'w:gz') as t:
 for f in source.iterdir():
  if f.is_file():shutil.copyfile(f,version/f.name);t.add(f,arcname=f.name)
run('46-final-code-copy',15,[*lima,'copy',str(archive),'s2-lifecycle:/tmp/v14.tar.gz'])
run('47-final-environment',60,[*lima,'shell','--workdir=/tmp','s2-lifecycle','sudo','sh','-c','mkdir -m 700 /opt/ontosary-fixture; mkdir -m 700 /opt/ontosary-fixture/code; tar xzf /tmp/v14.tar.gz -C /opt/ontosary-fixture/code; python3 /opt/ontosary-fixture/code/image.py docker.io/library/ontosary-s2-lifecycle:20261110'])
(base/'reprepare.json').write_text(json.dumps({'start':start,'endUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'endMono':time.monotonic(),'seconds':time.monotonic()-start['mono']},indent=2)+'\n')
