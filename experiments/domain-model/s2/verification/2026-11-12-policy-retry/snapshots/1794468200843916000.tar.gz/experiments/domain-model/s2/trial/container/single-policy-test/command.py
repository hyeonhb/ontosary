#!/usr/bin/env python3
"""Snapshot first, then recompute the single absolute host deadline before dispatch."""
import argparse,json,pathlib
from snapshot import snapshot
from deadline import run
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--ledger',required=True);p.add_argument('--log',required=True);p.add_argument('--phase',required=True);p.add_argument('--timeout',type=float);p.add_argument('--category',choices=['analysis','closing'],default='analysis');p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
 lp=pathlib.Path(a.ledger);cmd=a.command[1:] if a.command[:1]==['--'] else a.command;identity=snapshot(lp.parent,cmd,a.phase,a.category)
 with pathlib.Path(a.log).open('x') as log:result=run(cmd,json.loads(lp.read_text()),a.phase,lp.parent/'commands.jsonl',a.timeout,stdout=log)
 result['snapshot']=identity;d=json.loads(lp.read_text());d['events'].append(result);lp.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(result));raise SystemExit(result['exitCode'])
