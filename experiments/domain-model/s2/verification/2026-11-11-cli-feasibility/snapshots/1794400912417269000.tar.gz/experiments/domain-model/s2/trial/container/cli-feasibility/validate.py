"""Host checks only. Reuse an authentic prior receipt, never manufacture new authority."""
import pathlib,subprocess
base=pathlib.Path('experiments/domain-model/s2/trial/container')
for p in (base/'cli-feasibility').glob('*.py'):compile(p.read_text(),str(p),'exec')
for args in [
 ['pnpm','s2:build'],
 ['python3',str(base/'lifecycle/test_collector.py')],
 ['python3',str(base/'lifecycle/test_cleanup.py')],
 ['node',str(base/'lifecycle/refusal.mjs'),'work/s2-linux-evaluation/job-probes/7ca7f2d67f77/raw/result'],
]:
 print('CHECK',args,flush=True);subprocess.run(args,check=True,timeout=60)
